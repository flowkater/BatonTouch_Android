package com.ttshrk.view;

public interface ScrollPickerViewListener {
	public void onTouchUp(int slotId);
	public void onSingleTapUp(int slotId);
	public void onScrollEnd(int slotId);
}
